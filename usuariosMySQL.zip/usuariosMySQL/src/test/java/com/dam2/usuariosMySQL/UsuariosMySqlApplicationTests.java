package com.dam2.usuariosMySQL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuariosMySqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
