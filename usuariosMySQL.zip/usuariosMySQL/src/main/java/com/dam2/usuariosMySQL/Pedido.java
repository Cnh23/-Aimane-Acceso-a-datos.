package com.dam2.usuariosMySQL;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Pedido {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@Column(nullable = false)
	private String articulo;
	
    @Column(nullable = false)
	@DateTimeFormat(pattern = "yyyy-MM-dd", fallbackPatterns = {"dd-MM-yyyy", "dd/MM/yyyy"})
	private Date fechaPedido;
    
    @Column(nullable = false)
	@DateTimeFormat(pattern = "yyyy-MM-dd", fallbackPatterns = {"dd-MM-yyyy", "dd/MM/yyyy"})
	private Date fechaEntrega;
    
    @Column(nullable = false)
	private String estado = "nuevo";
	
	// La tarea pertenece a un unico cliente
	@ManyToOne
	@JoinColumn(name="usuario_id")
	private Usuario usuario;
	
	
	
	public Pedido() {
		
	}

	public Pedido(String articulo, Usuario usuario) {
		this.fechaPedido = new Date();
		this.fechaEntrega = new Date(this.fechaPedido.getTime() + 10 * 24 * 60 * 60 * 1000);
		this.articulo = articulo;
		this.usuario = usuario;
	}

	public Integer getId() {
		return id;
	}

	public Date getFechaPedido() {
		return fechaPedido;
	}

	public Date getFechaEntrega() {
		return fechaEntrega;
	}

	public String getEstado() {
		return estado;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public void setFechaPedido(Date fechaPedido) {
		this.fechaPedido = fechaPedido;
	}

	public void setFechaEntrega(Date fechaEntrega) {
		this.fechaEntrega = fechaEntrega;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public String getArticulo() {
		return articulo;
	}

	public void setArticulo(String articulo) {
		this.articulo = articulo;
	}
		
	
}
