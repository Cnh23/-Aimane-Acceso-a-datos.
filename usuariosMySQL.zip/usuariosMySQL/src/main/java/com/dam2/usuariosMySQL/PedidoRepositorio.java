package com.dam2.usuariosMySQL;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface PedidoRepositorio  extends CrudRepository<Pedido, Integer>{
List<Pedido> findByArticulo(String paramArticulo);
List<Pedido> findByUsuario(Usuario paramCliente);
}
