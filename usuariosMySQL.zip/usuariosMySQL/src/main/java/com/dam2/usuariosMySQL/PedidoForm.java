package com.dam2.usuariosMySQL;

import javax.validation.constraints.NotNull;

import jakarta.validation.constraints.NotBlank;
public class PedidoForm {
	
	@NotBlank(message = "El artículo es requerido")
	private String articulo;
	
	@NotNull(message = "El usuario es requerido")
	private Usuario usuario;
	
	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public String getArticulo() {
		return articulo;
	}

	public void setArticulo(String articulo) {
		this.articulo = articulo;
	}
	
	
}
