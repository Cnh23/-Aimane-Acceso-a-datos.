package com.dam2.usuariosMySQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsuariosMySqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsuariosMySqlApplication.class, args);
	}

}
