package com.dam2.models;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.dam2.usuariosMySQL.Pedido;
import com.dam2.usuariosMySQL.PedidoForm;
import com.dam2.usuariosMySQL.PedidoRepositorio;
import com.dam2.usuariosMySQL.Usuario;
import com.dam2.usuariosMySQL.UsuarioForm;
import com.dam2.usuariosMySQL.UsuarioRepositorio;

import jakarta.validation.Valid;



@Controller // Esto indica que la clase es un controller
public class ControladorPrincipal {

	@Autowired // Indicamos que cargamos el bean llamado Usuario repositorio
	private UsuarioRepositorio usuarioRepositorio;
	@Autowired
	private PedidoRepositorio pedidoRepositorio;
	
	@GetMapping("/inicio")
	public String iniPg() {
		return "index";
	}
		
	@GetMapping(path="/listado")
	public String getListaUsuarios (Model modelo) {
		modelo.addAttribute("listado",  usuarioRepositorio.findAll());
		return "/listado";
	}
	
	// Cuando venimos desde Get para dar de alta al usuario
	@GetMapping(path="/alta")
	public String showForm(UsuarioForm personForm) {
		return "/alta";
	}
	
	// Venimos desde alta y rellenar los datos, validamos los datos
	@PostMapping(path="/alta")
	public String checkPersonInfo(@Valid UsuarioForm usuForm, BindingResult bindingResult, Model modelo) {
		if (bindingResult.hasErrors()) {
			return "/alta";
		}	
		Usuario usuNuevo = new Usuario(usuForm.getName(), usuForm.getEmail());
		usuarioRepositorio.save(usuNuevo);
		modelo.addAttribute("mensaje", "Usuario " +usuForm.getName() + " dado de alta correctamente.");
		return "/index";
	}
	
	@GetMapping(path="/listadopedidos")
	public String getListaPedidos (Model modelo) {
		modelo.addAttribute("listado",  pedidoRepositorio.findAll());
		return "/listadopedidos";
	}
	
	// Cuando venimos desde Get para dar de alta al usuario
	@GetMapping(path="/altapedidos")
	public String showFormPedidos(PedidoForm pedidoForm, Model modelo) {
	    List<Usuario> listado = (List<Usuario>) usuarioRepositorio.findAll();
	    modelo.addAttribute("listadoselect", listado);
		return "/altapedidos";
	}
	
	// Venimos desde alta y rellenar los datos, validamos los datos
	@PostMapping(path="/altapedidos")
	public String checkPedidoInfo(@Valid PedidoForm pedForm, BindingResult bindingResult, Model modelo) {
		if (bindingResult.hasErrors()) {
			return "/altapedidos";
		}	
		Pedido pedido = new Pedido(pedForm.getArticulo(), pedForm.getUsuario());
		pedidoRepositorio.save(pedido);
		modelo.addAttribute("mensaje", "Artículo " + pedForm.getArticulo() + " dado de alta correctamente.");
		return "/index";
	}
	
	// Cuando venimos desde Get para dar de alta al pedido
		@GetMapping(path="/buscararticulo")
		public String showFormBuscarA(PedidoForm pedidoForm, Model modelo) {
			return "/buscararticulo";
		}
		
		// Venimos desde alta y rellenar los datos, validamos los datos
		@PostMapping(path="/buscararticulo")
		public String checkPedidoBuscarA(@Valid PedidoForm pedForm, BindingResult bindingResult, Model modelo) {
			if (bindingResult.hasErrors()) {
				return "/buscararticulo";
			}
			modelo.addAttribute("listado",  pedidoRepositorio.findByArticulo(pedForm.getArticulo()));
			return "/listadopedidos";
		}
		
		
		
		
		
		// Cuando venimos desde Get para dar de alta al pedido
		@GetMapping(path="/buscarcliente")
		public String showFormBuscarC(PedidoForm pedidoForm, Model modelo) {
		    List<Usuario> listado = (List<Usuario>) usuarioRepositorio.findAll();
		    modelo.addAttribute("listado", listado);
			return "/buscarcliente";
		}
		
		
		// Venimos desde alta y rellenar los datos, validamos los datos
		@PostMapping(path="/buscarcliente")
		public String checkClienteBuscarC(@Valid PedidoForm pedForm, BindingResult bindingResult, Model modelo) {
			modelo.addAttribute("listado",  pedidoRepositorio.findByUsuario(pedForm.getUsuario()));
			return "/listadopedidos";
		}
}
